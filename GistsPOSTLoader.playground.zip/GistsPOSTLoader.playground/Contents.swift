import UIKit

struct Gist: Encodable {
    var description: String
    var isPublic: Bool
    var content: String
    
    enum CodingKeys: String, CodingKey {
        case description = "description"
        case isPublic = "public"
        case files = "files"
        case filename = "MyFile.swift"
        case content = "content"
    }
    
    func encode(to encoder: Encoder) throws {
      var container = encoder.container(keyedBy: CodingKeys.self)
      try container.encode(description, forKey: .description)
      try container.encode(isPublic, forKey: .isPublic)
        var files = container.nestedContainer(keyedBy: CodingKeys.self, forKey: .files)
        var file = files.nestedContainer(keyedBy: CodingKeys.self, forKey: .filename)
        try file.encode(content, forKey: .content)
    }
}

let token = ""
let githubUrl = "https://api.github.com/gists"

let gistText = "print(\"Hello world!\")"

var gist: Gist
let newGist = Gist(description: "Print", isPublic: true, content: gistText)

let components = URLComponents(string: githubUrl)
if let url = components?.url {
    var request = URLRequest(url: url)
    request.httpMethod = "POST"
    request.setValue("token \(token)", forHTTPHeaderField: "Authorization")
    let dataToSend = try? JSONEncoder().encode(newGist.self)
    request.httpBody = dataToSend
    
    let task = URLSession.shared.dataTask(with: request) { (data, response, error) in

        if let data = data, error == nil, let responseData = String(data: data, encoding: .utf8) {
            print("Response data: \(responseData)")
        }
    }
    task.resume()
}

